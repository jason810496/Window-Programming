﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Q2_F74116720_LiuZheYou
{
    public partial class Form1 : Form
    {
        public static bool GameStart = false;
        public static int N = 5;
        public static int M = 6;
        public static int Alpha = 26;
        public static  Button[,] BtnArr = new Button[5, 6];
        public static Button[] KeyArr = new Button[26];
        public static List<string> DB = new List<string>();

        public static int StrLen = 0;
        public static int Row = 0;
        public static int Col = 0;
        public static string Str;
        public static string CorrectStr;
        public Form1()
        {
            InitializeComponent();
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            StreamReader R = new StreamReader("Wordlist.txt");
            do
            {
                var raw = R.ReadLine();
                if (raw == null) break;
                Console.WriteLine(raw);

                DB.Add(raw.ToUpper() );
            } while (true);

            R.Close();


            InputBox.Left += 1000;

            Random rd = new Random();
            CorrectStr = DB[rd.Next(DB.Count)];
        }

        private void KeyBtnClick(object sender, EventArgs e)
        {
            Button Btn = (Button)sender;

            char c = Btn.Text[0];

            if (StrLen < 5)
            {
                Str = Str + c.ToString();
                StrLen++;

                BtnArr[Row++, Col].Text = c.ToString();
            }
        }
        private void StartBtn_Click(object sender, EventArgs e)
        {
            ((Button)sender).Visible = false;

            MainLabel.Visible = true;
            SeeAnsBtn.Visible = true;
            EnterBtn.Visible = true;
            BackBtn.Visible = true;

            // Btn arr 
            int initX = 300;
            int initY = 50;
            int ht = 40;
            int wt = 40;

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < M; j++)
                {
                    BtnArr[i, j] = new Button();
                    BtnArr[i, j].SetBounds(initX + i * wt, initY + j * ht, wt, ht);
                    BtnArr[i, j].Visible = true;

                    Controls.Add(BtnArr[i, j]);
                }
            }

            // Key arr

            initX = 200;
            initY = 330;
            ht = 30;
            wt = 30;
            for (int i = 0; i < Alpha; i++)
            {
                KeyArr[i] = new Button();
                int posX = initX + (i % 13) * wt;
                int posY = initY + ht * (i / 13);
                KeyArr[i].SetBounds(posX, posY, wt, ht);
                KeyArr[i].Visible = true;
                KeyArr[i].Text = ((char)(i + 'A')).ToString();

                KeyArr[i].Click += new EventHandler(KeyBtnClick);

                Controls.Add(KeyArr[i]);
            }

            GameStart = true;

            // some information for testing TA
            MessageBox.Show("在測試Keyboard input 需要先切換英打才能用\n 滑鼠跟鍵盤混用的時候很常 Keyboard 會讀不到,所以順便用一個 backspace button", "Infor", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SeeAnsBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show(CorrectStr,"Hint", MessageBoxButtons.OK);
        }

        private void InputBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;

            if ( 'a'<=c && c<='z')
            {
                c = (char)(c + ( 'A' - 'a' ) );
            }
            
            if( GameStart)
            {
                if( 'A'<=c && c<='Z')
                {
                    if( StrLen < 5)
                    {
                        Str = Str + c.ToString();
                        StrLen++;

                        BtnArr[Row++, Col].Text = c.ToString();
                    }
                }
            }
        }

        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if( GameStart)
            {
                if( e.KeyCode == Keys.Back)
                {
                    if( StrLen > 0)
                    {
                        StrLen--;
                        Row--;
                        BtnArr[Row, Col].Text = "";
                        Str = Str.Remove(StrLen);
                    }
                }

                if( e.KeyCode == Keys.Enter && StrLen == 5 )
                {
                    EnterEvent();
                }
            }
        }

        private void EnterBtn_Click(object sender, EventArgs e)
        {
            EnterEvent();
        }

        public void EnterEvent()
        {
            if (StrLen < 5) return;

            Console.WriteLine("Guess : " + Str);
            if( DB.Contains(Str))
            {
                if( Str == CorrectStr)
                {
                    for(int i = 0; i < 5; i++)
                    {
                        BtnArr[i, Col].BackColor = Color.Green;
                    }
                    MessageBox.Show("Win", "Right Guess!", MessageBoxButtons.OK);
                    Close();
                }
                else
                {
              
                    for(int i = 0; i < 5; i++)
                    {
                        int idx = BtnArr[i, Col].Text[0] - 'A';

                        if ( BtnArr[i,Col].Text == CorrectStr[i].ToString() )
                        {
                            BtnArr[i, Col].BackColor = Color.Green;
                            KeyArr[ idx ].BackColor = Color.Green;
                        }
                        else if( CorrectStr.Contains(BtnArr[i, Col].Text[0]) )
                        {
                            BtnArr[i, Col].BackColor = Color.Yellow;
                            KeyArr[idx].BackColor = Color.Yellow;
                        }
                        else
                        {
                            BtnArr[i, Col].BackColor = Color.Gray;
                            KeyArr[idx].BackColor = Color.Gray;
                        }

                    }
                }

                Col++;
                StrLen = 0;
                Row = 0;
                Str = "";

                if (Col >= 6)
                {
                    MessageBox.Show( "You Lose", "Poor Man LOL!", MessageBoxButtons.OK);
                    Close();
                }
            }
            else
            {
                MessageBox.Show("Error", "Not a word in the word list", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            if (StrLen > 0)
            {
                StrLen--;
                Row--;
                BtnArr[Row, Col].Text = "";
                Str = Str.Remove(StrLen);
            }
        }
    }
}

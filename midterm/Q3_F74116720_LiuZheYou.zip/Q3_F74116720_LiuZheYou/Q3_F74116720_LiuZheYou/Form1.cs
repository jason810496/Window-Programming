﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Q3_F74116720_LiuZheYou
{
    public partial class Form1 : Form
    {

        public static Button[,] BtnArr = new Button[5, 5];
        public static int[,] Q_Arr = new int[5, 5];
        public static int[,] A_Arr = new int[5, 5];
        public static string Path;
        public Form1()
        {
            InitializeComponent();

            int initX = 170;
            int initY = 20;
            int sz = 60;
            int span = 20;
            for (int i = 1; i <= 4; i++)
            {
                for (int j = 1; j <= 4; j++)
                {
                    BtnArr[i, j] = new Button();
                    BtnArr[i, j].SetBounds(initX + i*( sz + span) , initY + j * (sz + span) , sz, sz);
                }
            }

            for (int i = 1; i <= 4; i++)
            {
                for (int j = 1; j <= 4; j++)
                {
                    Controls.Add(BtnArr[i, j]);
                }
            }

            MessageBox.Show("我只有完成 Home Screen , Open File , Load File , Save File", "Infor", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void openFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog Op = new OpenFileDialog();
            Op.Filter = "Text Files(*.txt)|*.txt|All Files(*.*)|*.*";
            Op.ShowDialog();

            Path = Op.FileName;
            

            

            StreamReader R = new StreamReader(Path);

            string raw;
            // Q
            for(int i = 1; i <=4; i++)
            {
                raw = R.ReadLine();
                Console.WriteLine(raw);
                if (raw == null) continue;
                for(int j = 1; j <= 4; j++)
                {
                    char c = raw[j - 1];
                    if ( c == '-') continue;
                    
                    BtnArr[i, j].Text = c.ToString();
                    BtnArr[i, j].ForeColor = Color.Black;
                    Q_Arr[i, j] = c - '0';
                }
            }

            // U
            for (int i = 1; i <= 4; i++)
            {
                raw = R.ReadLine();
                Console.WriteLine(raw);
                if (raw == null) continue;
                for (int j = 1; j <= 4; j++)
                {
                    char c = raw[j - 1];
                    if (c == '-') continue;
                    A_Arr[i, j] = c - '0';

                    if (BtnArr[i, j].Text.Length != 0) continue;
                    BtnArr[i, j].Text = c.ToString();
                    BtnArr[i, j].ForeColor = Color.Blue;
                    
                }
            }

            R.Close();

        }

        private void saveFileToolStripMenuItem_Click(object sender, EventArgs e)
        {

            string result = "";
            for(int i = 1; i <= 4; i++)
            {
                for(int j = 1; j <= 4; j++)
                {
                    result += (Q_Arr[i,j] == 0 ? "-" : Q_Arr[i,j].ToString() );
                }
                result += "\n";
            }

            for (int i = 1; i <= 4; i++)
            {
                for (int j = 1; j <= 4; j++)
                {
                    result += (A_Arr[i, j] == 0 ? "-" : A_Arr[i, j].ToString());
                }
                result += "\n";
            }
            StreamWriter R = new StreamWriter(Path);
            R.Write(result);
            R.Close();
        }
    }
}

﻿namespace F74116720_practice_3_2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.startStatusBar = new System.Windows.Forms.RichTextBox();
            this.startLabel1 = new System.Windows.Forms.Label();
            this.startLabel2 = new System.Windows.Forms.Label();
            this.startLabel3 = new System.Windows.Forms.Label();
            this.startLabel4 = new System.Windows.Forms.Label();
            this.startGameBtn = new System.Windows.Forms.Button();
            this.startTextBox1 = new System.Windows.Forms.TextBox();
            this.startTextBox2 = new System.Windows.Forms.TextBox();
            this.startTextBox3 = new System.Windows.Forms.TextBox();
            this.startTextBox4 = new System.Windows.Forms.TextBox();
            this.gameLabel1 = new System.Windows.Forms.Label();
            this.gameLabel2 = new System.Windows.Forms.Label();
            this.gameLabel3 = new System.Windows.Forms.Label();
            this.gameLabel4 = new System.Windows.Forms.Label();
            this.gameStack1 = new System.Windows.Forms.RichTextBox();
            this.gameStack2 = new System.Windows.Forms.RichTextBox();
            this.gameStack3 = new System.Windows.Forms.RichTextBox();
            this.gameStack4 = new System.Windows.Forms.RichTextBox();
            this.gameStackBtn1 = new System.Windows.Forms.Button();
            this.gameStackBtn2 = new System.Windows.Forms.Button();
            this.gameStackBtn3 = new System.Windows.Forms.Button();
            this.gameStackBtn4 = new System.Windows.Forms.Button();
            this.gameStatusBar = new System.Windows.Forms.RichTextBox();
            this.gamePauseBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // startStatusBar
            // 
            this.startStatusBar.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startStatusBar.Location = new System.Drawing.Point(329, 106);
            this.startStatusBar.Name = "startStatusBar";
            this.startStatusBar.ReadOnly = true;
            this.startStatusBar.Size = new System.Drawing.Size(574, 71);
            this.startStatusBar.TabIndex = 0;
            this.startStatusBar.Text = "Please input testCase";
            // 
            // startLabel1
            // 
            this.startLabel1.AutoSize = true;
            this.startLabel1.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startLabel1.Location = new System.Drawing.Point(121, 254);
            this.startLabel1.Name = "startLabel1";
            this.startLabel1.Size = new System.Drawing.Size(140, 50);
            this.startLabel1.TabIndex = 1;
            this.startLabel1.Text = "stack1";
            // 
            // startLabel2
            // 
            this.startLabel2.AutoSize = true;
            this.startLabel2.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startLabel2.Location = new System.Drawing.Point(121, 387);
            this.startLabel2.Name = "startLabel2";
            this.startLabel2.Size = new System.Drawing.Size(140, 50);
            this.startLabel2.TabIndex = 2;
            this.startLabel2.Text = "stack2";
            // 
            // startLabel3
            // 
            this.startLabel3.AutoSize = true;
            this.startLabel3.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startLabel3.Location = new System.Drawing.Point(121, 496);
            this.startLabel3.Name = "startLabel3";
            this.startLabel3.Size = new System.Drawing.Size(140, 50);
            this.startLabel3.TabIndex = 3;
            this.startLabel3.Text = "stack3";
            // 
            // startLabel4
            // 
            this.startLabel4.AutoSize = true;
            this.startLabel4.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startLabel4.Location = new System.Drawing.Point(121, 620);
            this.startLabel4.Name = "startLabel4";
            this.startLabel4.Size = new System.Drawing.Size(140, 50);
            this.startLabel4.TabIndex = 4;
            this.startLabel4.Text = "stack4";
            // 
            // startGameBtn
            // 
            this.startGameBtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startGameBtn.Location = new System.Drawing.Point(436, 757);
            this.startGameBtn.Name = "startGameBtn";
            this.startGameBtn.Size = new System.Drawing.Size(335, 57);
            this.startGameBtn.TabIndex = 5;
            this.startGameBtn.Text = "Start Game";
            this.startGameBtn.UseVisualStyleBackColor = true;
            this.startGameBtn.Click += new System.EventHandler(this.startGameBtn_Click);
            // 
            // startTextBox1
            // 
            this.startTextBox1.Location = new System.Drawing.Point(356, 254);
            this.startTextBox1.Name = "startTextBox1";
            this.startTextBox1.Size = new System.Drawing.Size(487, 36);
            this.startTextBox1.TabIndex = 6;
            // 
            // startTextBox2
            // 
            this.startTextBox2.Location = new System.Drawing.Point(356, 387);
            this.startTextBox2.Name = "startTextBox2";
            this.startTextBox2.Size = new System.Drawing.Size(487, 36);
            this.startTextBox2.TabIndex = 7;
            // 
            // startTextBox3
            // 
            this.startTextBox3.Location = new System.Drawing.Point(356, 496);
            this.startTextBox3.Name = "startTextBox3";
            this.startTextBox3.Size = new System.Drawing.Size(487, 36);
            this.startTextBox3.TabIndex = 8;
            // 
            // startTextBox4
            // 
            this.startTextBox4.Location = new System.Drawing.Point(356, 620);
            this.startTextBox4.Name = "startTextBox4";
            this.startTextBox4.Size = new System.Drawing.Size(487, 36);
            this.startTextBox4.TabIndex = 9;
            // 
            // gameLabel1
            // 
            this.gameLabel1.AutoSize = true;
            this.gameLabel1.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLabel1.Location = new System.Drawing.Point(101, 44);
            this.gameLabel1.Name = "gameLabel1";
            this.gameLabel1.Size = new System.Drawing.Size(140, 50);
            this.gameLabel1.TabIndex = 10;
            this.gameLabel1.Text = "stack1";
            // 
            // gameLabel2
            // 
            this.gameLabel2.AutoSize = true;
            this.gameLabel2.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLabel2.Location = new System.Drawing.Point(376, 44);
            this.gameLabel2.Name = "gameLabel2";
            this.gameLabel2.Size = new System.Drawing.Size(140, 50);
            this.gameLabel2.TabIndex = 11;
            this.gameLabel2.Text = "stack2";
            // 
            // gameLabel3
            // 
            this.gameLabel3.AutoSize = true;
            this.gameLabel3.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLabel3.Location = new System.Drawing.Point(681, 44);
            this.gameLabel3.Name = "gameLabel3";
            this.gameLabel3.Size = new System.Drawing.Size(140, 50);
            this.gameLabel3.TabIndex = 12;
            this.gameLabel3.Text = "stack3";
            // 
            // gameLabel4
            // 
            this.gameLabel4.AutoSize = true;
            this.gameLabel4.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLabel4.Location = new System.Drawing.Point(963, 44);
            this.gameLabel4.Name = "gameLabel4";
            this.gameLabel4.Size = new System.Drawing.Size(140, 50);
            this.gameLabel4.TabIndex = 13;
            this.gameLabel4.Text = "stack4";
            // 
            // gameStack1
            // 
            this.gameStack1.Location = new System.Drawing.Point(110, 137);
            this.gameStack1.Name = "gameStack1";
            this.gameStack1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.gameStack1.Size = new System.Drawing.Size(102, 480);
            this.gameStack1.TabIndex = 14;
            this.gameStack1.Text = "";
            // 
            // gameStack2
            // 
            this.gameStack2.Location = new System.Drawing.Point(385, 137);
            this.gameStack2.Name = "gameStack2";
            this.gameStack2.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.gameStack2.Size = new System.Drawing.Size(102, 480);
            this.gameStack2.TabIndex = 15;
            this.gameStack2.Text = "";
            // 
            // gameStack3
            // 
            this.gameStack3.Location = new System.Drawing.Point(690, 134);
            this.gameStack3.Name = "gameStack3";
            this.gameStack3.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.gameStack3.Size = new System.Drawing.Size(102, 480);
            this.gameStack3.TabIndex = 16;
            this.gameStack3.Text = "";
            // 
            // gameStack4
            // 
            this.gameStack4.Location = new System.Drawing.Point(972, 137);
            this.gameStack4.Name = "gameStack4";
            this.gameStack4.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.gameStack4.Size = new System.Drawing.Size(102, 480);
            this.gameStack4.TabIndex = 17;
            this.gameStack4.Text = "";
            // 
            // gameStackBtn1
            // 
            this.gameStackBtn1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameStackBtn1.Location = new System.Drawing.Point(97, 646);
            this.gameStackBtn1.Name = "gameStackBtn1";
            this.gameStackBtn1.Size = new System.Drawing.Size(124, 64);
            this.gameStackBtn1.TabIndex = 18;
            this.gameStackBtn1.Text = "button1";
            this.gameStackBtn1.UseVisualStyleBackColor = true;
            // 
            // gameStackBtn2
            // 
            this.gameStackBtn2.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameStackBtn2.Location = new System.Drawing.Point(385, 646);
            this.gameStackBtn2.Name = "gameStackBtn2";
            this.gameStackBtn2.Size = new System.Drawing.Size(124, 64);
            this.gameStackBtn2.TabIndex = 19;
            this.gameStackBtn2.Text = "button1";
            this.gameStackBtn2.UseVisualStyleBackColor = true;
            // 
            // gameStackBtn3
            // 
            this.gameStackBtn3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameStackBtn3.Location = new System.Drawing.Point(690, 646);
            this.gameStackBtn3.Name = "gameStackBtn3";
            this.gameStackBtn3.Size = new System.Drawing.Size(124, 64);
            this.gameStackBtn3.TabIndex = 20;
            this.gameStackBtn3.Text = "button1";
            this.gameStackBtn3.UseVisualStyleBackColor = true;
            // 
            // gameStackBtn4
            // 
            this.gameStackBtn4.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameStackBtn4.Location = new System.Drawing.Point(972, 646);
            this.gameStackBtn4.Name = "gameStackBtn4";
            this.gameStackBtn4.Size = new System.Drawing.Size(124, 64);
            this.gameStackBtn4.TabIndex = 21;
            this.gameStackBtn4.Text = "button1";
            this.gameStackBtn4.UseVisualStyleBackColor = true;
            // 
            // gameStatusBar
            // 
            this.gameStatusBar.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameStatusBar.Location = new System.Drawing.Point(97, 770);
            this.gameStatusBar.Name = "gameStatusBar";
            this.gameStatusBar.ReadOnly = true;
            this.gameStatusBar.Size = new System.Drawing.Size(491, 72);
            this.gameStatusBar.TabIndex = 22;
            this.gameStatusBar.Text = "Please input testCase";
            // 
            // gamePauseBtn
            // 
            this.gamePauseBtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gamePauseBtn.Location = new System.Drawing.Point(715, 770);
            this.gamePauseBtn.Name = "gamePauseBtn";
            this.gamePauseBtn.Size = new System.Drawing.Size(335, 57);
            this.gamePauseBtn.TabIndex = 23;
            this.gamePauseBtn.Text = "Retuen to Menu";
            this.gamePauseBtn.UseVisualStyleBackColor = true;
            this.gamePauseBtn.Click += new System.EventHandler(this.gamePauseBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1196, 911);
            this.Controls.Add(this.gamePauseBtn);
            this.Controls.Add(this.gameStatusBar);
            this.Controls.Add(this.gameStackBtn4);
            this.Controls.Add(this.gameStackBtn3);
            this.Controls.Add(this.gameStackBtn2);
            this.Controls.Add(this.gameStackBtn1);
            this.Controls.Add(this.gameStack4);
            this.Controls.Add(this.gameStack3);
            this.Controls.Add(this.gameStack2);
            this.Controls.Add(this.gameStack1);
            this.Controls.Add(this.gameLabel4);
            this.Controls.Add(this.gameLabel3);
            this.Controls.Add(this.gameLabel2);
            this.Controls.Add(this.gameLabel1);
            this.Controls.Add(this.startTextBox4);
            this.Controls.Add(this.startTextBox3);
            this.Controls.Add(this.startTextBox2);
            this.Controls.Add(this.startTextBox1);
            this.Controls.Add(this.startGameBtn);
            this.Controls.Add(this.startLabel4);
            this.Controls.Add(this.startLabel3);
            this.Controls.Add(this.startLabel2);
            this.Controls.Add(this.startLabel1);
            this.Controls.Add(this.startStatusBar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox startStatusBar;
        private System.Windows.Forms.Label startLabel1;
        private System.Windows.Forms.Label startLabel2;
        private System.Windows.Forms.Label startLabel3;
        private System.Windows.Forms.Label startLabel4;
        private System.Windows.Forms.Button startGameBtn;
        private System.Windows.Forms.TextBox startTextBox1;
        private System.Windows.Forms.TextBox startTextBox2;
        private System.Windows.Forms.TextBox startTextBox3;
        private System.Windows.Forms.TextBox startTextBox4;
        private System.Windows.Forms.Label gameLabel1;
        private System.Windows.Forms.Label gameLabel2;
        private System.Windows.Forms.Label gameLabel3;
        private System.Windows.Forms.Label gameLabel4;
        private System.Windows.Forms.RichTextBox gameStack1;
        private System.Windows.Forms.RichTextBox gameStack2;
        private System.Windows.Forms.RichTextBox gameStack3;
        private System.Windows.Forms.RichTextBox gameStack4;
        private System.Windows.Forms.Button gameStackBtn1;
        private System.Windows.Forms.Button gameStackBtn2;
        private System.Windows.Forms.Button gameStackBtn3;
        private System.Windows.Forms.Button gameStackBtn4;
        private System.Windows.Forms.RichTextBox gameStatusBar;
        private System.Windows.Forms.Button gamePauseBtn;
    }
}


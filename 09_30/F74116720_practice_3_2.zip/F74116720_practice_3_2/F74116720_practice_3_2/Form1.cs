﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace F74116720_practice_3_2
{
    public partial class Form1 : Form
    {
        private bool GameStarted = false;
        private Game G;
        int selectedIdx = -1;
        int toIdx = -1;
        class Game
        {
            private List<int>[] stacks;
            
            public bool canplace(int i)
            {
                return stacks[i].Count < 4 ;
            }

            public bool canselect(int i)
            {
                return stacks[i].Count > 0;
            }

            public void move(int i, int j)
            {
                int val = stacks[i].Last();
                stacks[i].RemoveAt(stacks[i].Count - 1);
                stacks[j].Add( val );
                
            }

            public string output(int i)
            {
                int cnt = 15 - stacks[i].Count;
                string ans = "";
                for (int j = 0; j < cnt; j++)
                {
                    ans += "\n";
                }


                cnt = stacks[i].Count;
                for (int j= cnt-1; j >= 0; j--)
                {
                    ans += stacks[i][j].ToString() + "\n";
                }
                return ans;
            }

            public bool win()
            {
                Dictionary<string, int> dic = new Dictionary<string, int>()
                {
                    {"1", 0},
                    {"2", 0},
                    {"3", 0},
                };
                
                for(int i = 0; i < 4; i++)
                {
                    if (stacks[i].Count == 0) continue;

                    int ft = stacks[i].First();
                    foreach(int ele in stacks[i])
                    {
                        if (ele != ft) return false;
                    }
                    dic[ft.ToString()]++;
                }

                Console.WriteLine("Last check {0}", dic);
                foreach (var item in dic)
                {
                    if (item.Value != 1)
                    {
                        return false;
                    }
                }

                return true;
            }

            public Game(string[] input)
            {
                stacks = new List<int>[5];
                for (int i = 0; i < 4; i++)
                {
                    stacks[i] = new List<int>();
                    string[] row = input[i].Split(' ');

                    if (row.Length == 1 && row[0].Length == 0 ) continue;
                    Console.Write(" row :[ ");
                    foreach (string s in row)
                    {
                        Console.Write("{0},",s);
                    }
                    Console.WriteLine(" ] ");
                    Console.WriteLine("input : row = [{0}]",row);
                    foreach(string s in row)
                    {
                        stacks[i].Add(int.Parse(s));
                    }
                }
            }
        }
        
        public Form1()
        {
            InitializeComponent();

            foreach (Control obj in this.Controls)
            {
                if (obj.Name.Contains("game"))
                {
                    obj.Visible = false;
                }
            }
            // init game btn 
            foreach (Control obj in this.Controls)
            {
                if (obj.Name.Contains("gameStackBtn"))
                {
                    obj.Click += gameStackBtn_Click;
                    obj.Text = "Select";
                }
            }
        }
        
        private bool checkInput()
        {
            Dictionary<string, int> dic = new Dictionary<string, int>()
            {
                {"1", 0},
                {"2", 0},
                {"3", 0},
            };
            List<string> stacks = new List<string>() { startTextBox1.Text, startTextBox2.Text, startTextBox3.Text, startTextBox4.Text };
            foreach (string stack in stacks)
            {
                if (stack.StartsWith(" ") || stack.Split(new char[1] { ' ' }).Length > 4)
                {
                    return false;
                }
                foreach (var item in stack)
                {
                    if (item != ' ' && !Char.IsDigit(item))
                    {
                        return false;
                    }
                    if (dic.ContainsKey(item.ToString())) dic[item.ToString()]++;
                }
            }
            foreach (var item in dic)
            {
                if (item.Value != 3)
                {
                    return false;
                }
            }

            return true;
        }
        private void StartGame()
        {
           
            string[] inp = { startTextBox1.Text , startTextBox2.Text, startTextBox3.Text, startTextBox4.Text };
            if(checkInput())
            {
                GameStarted = true;
                startStatusBar.Text = "";
                G = new Game(inp);
                // change rendrer view 
                foreach (Control obj in this.Controls)
                {
                    if (obj.Name.Contains("start") ){
                        obj.Visible = false;
                    }
                }
                foreach (Control obj in this.Controls)
                {
                    if (obj.Name.Contains("game") ){
                        obj.Visible = true;
                    }
                }
                // load game stack text box
                updateStacks();
                updateBtn();

                if (G.win())
                {
                    winRender();
                }
            }
            else
            {
                GameStarted = false;
                startStatusBar.Text = "Input Error";
            }
            
        }

        private void PauseGame()
        {
            GameStarted = false;
            foreach(Control obj in this.Controls)
            {
                if(obj.Name.Contains("start") ){
                    obj.Visible = true;
                }
            }
            foreach (Control obj in this.Controls)
            {
                if (obj.Name.Contains("game") ){
                    obj.Visible = false;
                }
            }

            startStatusBar.Text = "Please input testCase";
        }

        private void startGameBtn_Click(object sender, EventArgs e)
        {
            if (GameStarted)
            {
                PauseGame();
            }
            else
            {
                StartGame();
            }
        }

        private void gamePauseBtn_Click(object sender, EventArgs e)
        {
            PauseGame();
        }

        private void updateBtn()
        {
            foreach (Control obj in this.Controls)
            {
                if (obj.Name.Contains("gameStackBtn"))
                {
                    int idx = int.Parse(obj.Name.Last().ToString()) -1 ;
                    
                    if( selectedIdx == -1)
                    {
                        obj.Text = "Select";
                        if ( G.canselect(idx))
                        {
                            obj.Enabled = true;
                        }
                        else
                        {
                            obj.Enabled = false;
                        }
                    }
                    else
                    {
                        obj.Text = "Place";
                        if (G.canplace(idx))
                        {
                            obj.Enabled = true;
                        }
                        else
                        {
                            obj.Enabled = false;
                        }
                    }
                    
                }
            }
        }

        private void updateStacks()
        {
            gameStack1.Text = G.output(0);
            gameStack2.Text = G.output(1);
            gameStack3.Text = G.output(2);
            gameStack4.Text = G.output(3);
        }

        private void winRender()
        {
            foreach (Control obj in this.Controls)
            {
                if (obj.Name.Contains("gameStackBtn"))
                {
                    obj.Text = "Win";
                    obj.Enabled = false;
                }
            }
        }

        private void gameStackBtn_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if ( selectedIdx == -1)
            {
                //Console.Write("Btn.name = ");
                //Console.WriteLine(btn.Name);
                //Console.Write("Btn.name.last = ");
                //Console.WriteLine(btn.Name.Last().ToString());
                selectedIdx = int.Parse(btn.Name.Last().ToString()) -1;
            }
            else if( toIdx == -1 )
            {
                toIdx = int.Parse(btn.Name.Last().ToString()) -1;
                G.move(selectedIdx, toIdx);
                

                selectedIdx = -1;
                toIdx = -1;
            }


            updateBtn();
            updateStacks();

            if( G.win())
            {
                winRender();
            }
        }
    }
}

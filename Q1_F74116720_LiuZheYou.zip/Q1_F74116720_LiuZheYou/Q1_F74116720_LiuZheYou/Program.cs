﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1_F74116720_LiuZheYou
{
    class Program
    {
        public static int OrderCount = 0;
        public static int Profit = 0;
        public static int OrderA = 0;
        public static int OrderB = 0;
        public static int OrderC = 0;
        public static List<List<int>> DB = new List<List<int>>();
        public static void PrintInit()
        {
            Console.WriteLine("(1) View menu (2) Make an order (3) List the order (4) Complete order (5) View turnover (6) Baozi shop closed");
            Console.Write("Please input option:  ");
        }

        public static int GetInt()
        {
            string raw = Console.ReadLine();
            return int.Parse(raw);
        }

        public static void ViewMenu()
        {
            Console.Write("--------------I am Menu--------------\n");
            Console.Write("bamboo shoot bun\t\tNT$10\n");
            Console.Write("Char siew bun\t\t\tNT$20\n");
            Console.Write("Cry cry steamed bun\t\tNT$100\n");
        }
        public static void MakeOrder()
        {
            int a, b, c;
            Console.Write("number of bamboo shoot bun : ");
            a = GetInt();
            Console.Write("number of Char siew bun : ");
            b = GetInt();
            Console.Write("number of Cry cry steamed bun : ");
            c = GetInt();

            List<int> temp = new List<int>();

            temp.Add(OrderCount++);
            temp.Add(a);
            temp.Add(b);
            temp.Add(c);
            temp.Add(a * 10 + b * 20 + c * 100);
            temp.Add(0);

            DB.Add(temp);
        }

        public static void ListOrder()
        {
            foreach( List<int> ele in DB)
            {
                Console.WriteLine("============================");
                Console.WriteLine("Order number : {0}", ele[0]);
                Console.Write("bamboo shoot bun: {0}\n",ele[1] );
                Console.Write("Char siew bun: {0}\n", ele[2]);
                Console.Write("Cry cry steamed bun: {0}\n", ele[3]);
                Console.WriteLine();
                Console.WriteLine("Total amount: {0}", ele[4]);
                Console.WriteLine("Order status: {0}", (ele[5] == 0 ? "uncompleted\n" : "completed\n") );
                Console.WriteLine("============================");
            }
        }

        public static void CompleteOrder()
        {
            Console.Write("Enter the number of the order to be completed : ");
            int idx = GetInt();

            if( idx >= OrderCount)
            {
                Console.WriteLine("The order doesn’t exist");
            }
            else
            {
                if(DB[idx][5] == 1)
                {
                    Console.WriteLine("The order is completed");
                }
                else
                {
                    // ok 
                    DB[idx][5] = 1;

                    Profit += DB[idx][4];
                    OrderA += DB[idx][1];
                    OrderB += DB[idx][2];
                    OrderC += DB[idx][3];
                }
            }
        }
        public static void ViewAll()
        {
            Console.WriteLine("turnover : {0}", Profit);
            Console.Write("bamboo shoot bun: {0}\n", OrderA);
            Console.Write("Char siew bun: {0}\n", OrderB);
            Console.Write("Cry cry steamed bun: {0}\n", OrderC);
        }
       static void Main(string[] args)
        {
            PrintInit();
            int opt = GetInt();
            while( opt != 6)
            {
                if( opt == 1)
                {
                    ViewMenu();
                }
                else if( opt == 2)
                {
                    MakeOrder();
                }
                else if (opt == 3)
                {
                    ListOrder();
                }
                else if (opt == 4)
                {
                    CompleteOrder();
                }
                else if (opt == 5)
                {
                    ViewAll();
                }
                PrintInit();
                opt = GetInt();
            }
            
        }
    }
}
